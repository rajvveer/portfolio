import React, { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import Particles from './components/common/Particles'
import Navbar from './components/layout/Navbar'
import MagneticCursor from './components/common/MagneticCursor'
import Hero from './sections/Hero'
import BentoGrid from './sections/BentoGrid'
import ProjectsShowcase from './sections/ProjectsShowcase'
import SkillsRadar from './sections/SkillsRadar'
import Timeline from './sections/Timeline'
import Contact from './sections/Contact'
import Testimonials from './sections/Testimonials'

function App() {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 })

  useEffect(() => {
    const handleMouseMove = (e) => {
      setMousePosition({ x: e.clientX, y: e.clientY })
    }

    window.addEventListener('mousemove', handleMouseMove)
    return () => window.removeEventListener('mousemove', handleMouseMove)
  }, [])

  return (
    <div className="relative min-h-screen">
      <Particles />
      <MagneticCursor position={mousePosition} />
      <Navbar />
      
      <main className="relative z-10">
        <Hero />
        <BentoGrid />
        <ProjectsShowcase />
        <SkillsRadar />
        <Timeline />
        <Testimonials/>
        <Contact />
      </main>

      {/* Floating Gradient Orbs */}
      <motion.div
        className="fixed top-1/4 right-10 w-32 h-32 rounded-full bg-gradient-to-r from-accent-pink to-accent-purple opacity-20 blur-3xl pointer-events-none z-0"
        animate={{ y: [0, -30, 0], scale: [1, 1.2, 1] }}
        transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
      />
      
      <motion.div
        className="fixed bottom-1/4 left-10 w-40 h-40 rounded-full bg-gradient-to-r from-accent-cyan to-primary-500 opacity-20 blur-3xl pointer-events-none z-0"
        animate={{ y: [0, 30, 0], scale: [1, 1.1, 1] }}
        transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
      />
    </div>
  )
}

export default App
