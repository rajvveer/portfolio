
export { default as logo } from './images/logo.png'
export { default as avatar } from './images/avatar.png'