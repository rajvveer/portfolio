export const testimonialsData = [
  {
    id: 1,
    name: "Angelo Domenico Parisi",
    role: "Business Head",
    company: "HaQademy",
    image: "https://gcavocats.ca/wp-content/uploads/2018/09/man-avatar-icon-flat-vector-19152370-1.jpg",
    rating: 5,
    date: "Nov 11, 2023",
    platform: "Fiverr",
    message: "Rajveer has created a fantastic website for my business, and I believe many others could level up through his skills. If I ever need to build a new site, I would definitely go back to him.",
  },
]
